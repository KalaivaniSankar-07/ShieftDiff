import type {
  ChangeCategory,
  FieldChange,
  HandoverItem,
  HandoverResult,
  RejectedEvent,
  ShiftEvent,
  Source,
  Status,
} from './types';

const COMPLETED_STATUSES: Status[] = ['Resolved', 'Closed', 'Completed'];
const BLOCKER_STATUSES: Status[] = ['Blocked', 'Escalated'];
const IN_PROGRESS_STATUSES: Status[] = [
  'Open',
  'Assigned',
  'Investigating',
  'In Progress',
  'in_progress',
];

function normalizeStatus(s: Status): string {
  return s.toLowerCase().replace(/\s+/g, '_');
}

function isCompleted(s: Status): boolean {
  return COMPLETED_STATUSES.some((c) => normalizeStatus(c) === normalizeStatus(s));
}
function isBlocker(s: Status): boolean {
  return BLOCKER_STATUSES.some((c) => normalizeStatus(c) === normalizeStatus(s));
}
function isInProgress(s: Status): boolean {
  return IN_PROGRESS_STATUSES.some((c) => normalizeStatus(c) === normalizeStatus(s));
}

function humanReason(
  category: ChangeCategory,
  finalStatus: Status,
): string {
  if (category === 'Completed') {
    return 'Resolved during this shift.';
  }
  if (category === 'Blockers / Escalations') {
    if (isBlocker(finalStatus)) {
      return `${finalStatus} during this shift — immediate follow-up required.`;
    }
    return 'Critical priority at shift end — immediate follow-up required.';
  }
  if (category === 'Watch-list') {
    return `High priority and unresolved — keep under observation next shift.`;
  }
  return `Still ${finalStatus.toLowerCase()} at shift end.`;
}

function classify(
  finalStatus: Status,
  finalPriority: string,
): { category: ChangeCategory; reason: string } {
  if (isCompleted(finalStatus)) {
    return { category: 'Completed', reason: `Final status = ${finalStatus}` };
  }
  if (isBlocker(finalStatus)) {
    return { category: 'Blockers / Escalations', reason: `Final status = ${finalStatus}` };
  }
  if (finalPriority === 'Critical') {
    return {
      category: 'Blockers / Escalations',
      reason: `Final priority = Critical`,
    };
  }
  if (isInProgress(finalStatus)) {
    return { category: 'In Progress', reason: `Final status = ${finalStatus}` };
  }
  return { category: 'In Progress', reason: `Final status = ${finalStatus}` };
}

function isWatchlist(item: HandoverItem): boolean {
  return (
    !isCompleted(item.finalStatus) &&
    (item.finalPriority === 'High' || item.finalPriority === 'Critical') &&
    item.category !== 'Blockers / Escalations'
  );
}

function detectChanges(first: ShiftEvent, last: ShiftEvent): FieldChange[] {
  const changes: FieldChange[] = [];
  const fields: Array<{ key: keyof ShiftEvent; label: string }> = [
    { key: 'status', label: 'Status' },
    { key: 'priority', label: 'Priority' },
    { key: 'owner', label: 'Owner' },
  ];
  for (const f of fields) {
    const from = String(first[f.key] ?? 'Not provided');
    const to = String(last[f.key] ?? 'Not provided');
    if (from !== to) {
      changes.push({ field: f.label, from, to });
    }
  }
  return changes;
}

export function generateHandover(
  events: ShiftEvent[],
  shiftStart: string,
  shiftEnd: string,
  enabledSources: Source[],
): HandoverResult {
  const startMs = new Date(shiftStart).getTime();
  const endMs = new Date(shiftEnd).getTime();

  const included: ShiftEvent[] = [];
  const rejected: RejectedEvent[] = [];

  for (const ev of events) {
    if (!enabledSources.includes(ev.source)) continue;
    const ts = new Date(ev.timestamp).getTime();
    if (ts >= startMs && ts < endMs) {
      included.push(ev);
    } else {
      const reason = ts < startMs ? 'Before shift start' : 'At/after shift end';
      rejected.push({ event: ev, reason });
    }
  }

  const groups = new Map<string, ShiftEvent[]>();
  for (const ev of included) {
    const key = `${ev.source}::${ev.record_id}`;
    const arr = groups.get(key);
    if (arr) arr.push(ev);
    else groups.set(key, [ev]);
  }

  const items: HandoverItem[] = [];
  let duplicatesCollapsed = 0;

  for (const [key, group] of groups) {
    const sorted = [...group].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
    );
    if (sorted.length > 1) duplicatesCollapsed += sorted.length - 1;

    const first = sorted[0];
    const last = sorted[sorted.length - 1];
    const changes = detectChanges(first, last);
    const { category, reason } = classify(last.status, last.priority);

    items.push({
      key,
      source: last.source,
      record_id: last.record_id,
      summary: last.summary || 'Not provided',
      events: sorted,
      firstEvent: first,
      lastEvent: last,
      changes,
      category,
      classificationReason: reason,
      humanReason: humanReason(category, last.status),
      latestTimestamp: last.timestamp,
      finalStatus: last.status,
      finalPriority: last.priority,
      finalOwner: last.owner || 'Not provided',
    });
  }

  for (const item of items) {
    if (item.category === 'In Progress' && isWatchlist(item)) {
      item.category = 'Watch-list';
      item.classificationReason = `Unresolved ${item.finalPriority} priority — needs next-shift attention`;
      item.humanReason = humanReason('Watch-list', item.finalStatus);
    }
  }

  // Sort items deterministically by key for reproducible output
  items.sort((a, b) => a.key.localeCompare(b.key));

  const meaningfulChanges = items.filter((i) => i.changes.length > 0).length;

  return {
    items,
    rejectedEvents: rejected,
    summary: {
      total: included.length + rejected.length,
      included: included.length,
      rejected: rejected.length,
      uniqueRecords: groups.size,
      duplicatesCollapsed,
      meaningfulChanges,
    },
  };
}

export function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString('en-US', {
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

export function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: '2-digit',
    year: 'numeric',
  });
}
