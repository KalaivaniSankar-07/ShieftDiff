export type Source = 'Ticketing System' | 'Incident Logs';

export type Status =
  | 'Open'
  | 'Assigned'
  | 'Investigating'
  | 'In Progress'
  | 'in_progress'
  | 'Blocked'
  | 'Escalated'
  | 'Resolved'
  | 'Closed'
  | 'Completed';

export type Priority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface ShiftEvent {
  id: string;
  source: Source;
  record_id: string;
  timestamp: string;
  summary: string;
  status: Status;
  priority: Priority;
  owner: string;
}

export type ChangeCategory =
  | 'Completed'
  | 'In Progress'
  | 'Blockers / Escalations'
  | 'Watch-list';

export interface FieldChange {
  field: string;
  from: string;
  to: string;
}

export interface HandoverItem {
  key: string;
  source: Source;
  record_id: string;
  summary: string;
  events: ShiftEvent[];
  firstEvent: ShiftEvent;
  lastEvent: ShiftEvent;
  changes: FieldChange[];
  category: ChangeCategory;
  classificationReason: string;
  humanReason: string;
  latestTimestamp: string;
  finalStatus: Status;
  finalPriority: Priority;
  finalOwner: string;
}

export interface RejectedEvent {
  event: ShiftEvent;
  reason: string;
}

export interface HandoverResult {
  items: HandoverItem[];
  rejectedEvents: RejectedEvent[];
  summary: {
    total: number;
    included: number;
    rejected: number;
    uniqueRecords: number;
    duplicatesCollapsed: number;
    meaningfulChanges: number;
  };
}
