import type { ShiftEvent } from './types';

// Shift window: 2026-09-03 17:00 → 2026-09-03 23:00
export const DEFAULT_SHIFT_START = '2026-09-03T17:00';
export const DEFAULT_SHIFT_END = '2026-09-03T23:00';

export const MOCK_EVENTS: ShiftEvent[] = [
  // ===== Inside the shift =====

  // INC-304 — escalated incident (multiple updates)
  {
    id: 'e1',
    source: 'Incident Logs',
    record_id: 'INC-304',
    timestamp: '2026-09-03T17:25:00',
    summary: 'Checkout API returning 500 errors',
    status: 'Open',
    priority: 'Medium',
    owner: 'Support',
  },
  {
    id: 'e2',
    source: 'Incident Logs',
    record_id: 'INC-304',
    timestamp: '2026-09-03T18:10:00',
    summary: 'Checkout API returning 500 errors',
    status: 'Investigating',
    priority: 'High',
    owner: 'Support',
  },
  {
    id: 'e3',
    source: 'Incident Logs',
    record_id: 'INC-304',
    timestamp: '2026-09-03T19:35:00',
    summary: 'Checkout API returning 500 errors',
    status: 'Escalated',
    priority: 'Critical',
    owner: 'Backend',
  },

  // TKT-1024 — resolved ticket
  {
    id: 'e4',
    source: 'Ticketing System',
    record_id: 'TKT-1024',
    timestamp: '2026-09-03T17:05:00',
    summary: 'Customer unable to reset password',
    status: 'Open',
    priority: 'Medium',
    owner: 'Support',
  },
  {
    id: 'e5',
    source: 'Ticketing System',
    record_id: 'TKT-1024',
    timestamp: '2026-09-03T18:20:00',
    summary: 'Customer unable to reset password',
    status: 'Assigned',
    priority: 'Medium',
    owner: 'IT Helpdesk',
  },
  {
    id: 'e6',
    source: 'Ticketing System',
    record_id: 'TKT-1024',
    timestamp: '2026-09-03T20:45:00',
    summary: 'Customer unable to reset password',
    status: 'Resolved',
    priority: 'Medium',
    owner: 'IT Helpdesk',
  },

  // TKT-1031 — in progress
  {
    id: 'e7',
    source: 'Ticketing System',
    record_id: 'TKT-1031',
    timestamp: '2026-09-03T17:40:00',
    summary: 'Email delivery delays reported',
    status: 'Open',
    priority: 'High',
    owner: 'Support',
  },
  {
    id: 'e8',
    source: 'Ticketing System',
    record_id: 'TKT-1031',
    timestamp: '2026-09-03T19:00:00',
    summary: 'Email delivery delays reported',
    status: 'In Progress',
    priority: 'High',
    owner: 'Infra Team',
  },

  // INC-312 — blocked incident
  {
    id: 'e9',
    source: 'Incident Logs',
    record_id: 'INC-312',
    timestamp: '2026-09-03T18:30:00',
    summary: 'Database replica lag exceeding threshold',
    status: 'Investigating',
    priority: 'High',
    owner: 'DBA',
  },
  {
    id: 'e10',
    source: 'Incident Logs',
    record_id: 'INC-312',
    timestamp: '2026-09-03T21:15:00',
    summary: 'Database replica lag exceeding threshold',
    status: 'Blocked',
    priority: 'High',
    owner: 'DBA',
  },

  // TKT-1040 — completed
  {
    id: 'e11',
    source: 'Ticketing System',
    record_id: 'TKT-1040',
    timestamp: '2026-09-03T19:10:00',
    summary: 'SSO configuration for new vendor',
    status: 'Assigned',
    priority: 'Low',
    owner: 'IT Helpdesk',
  },
  {
    id: 'e12',
    source: 'Ticketing System',
    record_id: 'TKT-1040',
    timestamp: '2026-09-03T22:00:00',
    summary: 'SSO configuration for new vendor',
    status: 'Completed',
    priority: 'Low',
    owner: 'IT Helpdesk',
  },

  // INC-318 — open high-priority (watch-list)
  {
    id: 'e13',
    source: 'Incident Logs',
    record_id: 'INC-318',
    timestamp: '2026-09-03T22:30:00',
    summary: 'Payment gateway intermittent timeouts',
    status: 'Open',
    priority: 'High',
    owner: 'Support',
  },

  // TKT-1052 — single update, in progress
  {
    id: 'e14',
    source: 'Ticketing System',
    record_id: 'TKT-1052',
    timestamp: '2026-09-03T20:00:00',
    summary: 'Mobile app crash on Android 14',
    status: 'Investigating',
    priority: 'Medium',
    owner: 'Mobile Team',
  },

  // ===== Outside the shift (rejected) =====

  {
    id: 'e15',
    source: 'Ticketing System',
    record_id: 'TKT-0988',
    timestamp: '2026-09-03T09:00:00',
    summary: 'Login page slow loading',
    status: 'Resolved',
    priority: 'Medium',
    owner: 'Frontend',
  },
  {
    id: 'e16',
    source: 'Incident Logs',
    record_id: 'INC-290',
    timestamp: '2026-09-03T08:30:00',
    summary: 'CDN cache miss spike',
    status: 'Closed',
    priority: 'Low',
    owner: 'Infra Team',
  },
  {
    id: 'e17',
    source: 'Ticketing System',
    record_id: 'TKT-1024',
    timestamp: '2026-09-04T01:00:00',
    summary: 'Customer unable to reset password',
    status: 'Closed',
    priority: 'Medium',
    owner: 'IT Helpdesk',
  },
  {
    id: 'e18',
    source: 'Incident Logs',
    record_id: 'INC-305',
    timestamp: '2026-09-04T00:30:00',
    summary: 'Rate limiter misconfigured',
    status: 'Open',
    priority: 'Critical',
    owner: 'Backend',
  },
  {
    id: 'e19',
    source: 'Ticketing System',
    record_id: 'TKT-1015',
    timestamp: '2026-09-02T14:00:00',
    summary: 'Billing discrepancy on invoice #4521',
    status: 'Assigned',
    priority: 'Low',
    owner: 'Finance Ops',
  },
];
