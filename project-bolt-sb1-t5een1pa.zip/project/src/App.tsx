import { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Download,
  Eye,
  Filter,
  GitCompare,
  Info,
  Layers,
  Loader2,
  ShieldAlert,
  ShieldCheck,
  X,
  XCircle,
} from 'lucide-react';
import {
  DEFAULT_SHIFT_END,
  DEFAULT_SHIFT_START,
  MOCK_EVENTS,
} from './data';
import {
  formatDate,
  formatTime,
  formatTimestamp,
  generateHandover,
} from './logic';
import type {
  ChangeCategory,
  HandoverItem,
  HandoverResult,
  RejectedEvent,
  Source,
} from './types';

const ALL_SOURCES: Source[] = ['Ticketing System', 'Incident Logs'];

const CATEGORY_ORDER: ChangeCategory[] = [
  'Blockers / Escalations',
  'In Progress',
  'Watch-list',
  'Completed',
];

const CATEGORY_CONFIG: Record<
  ChangeCategory,
  {
    icon: typeof CheckCircle2;
    color: string;
    bg: string;
    border: string;
    text: string;
    dot: string;
    label: string;
    subtitle: string;
  }
> = {
  'Blockers / Escalations': {
    icon: ShieldAlert,
    color: 'text-red-600',
    bg: 'bg-red-50',
    border: 'border-red-200',
    text: 'text-red-700',
    dot: 'bg-red-500',
    label: 'Blockers',
    subtitle: 'Requires immediate attention',
  },
  'In Progress': {
    icon: Clock,
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    text: 'text-amber-700',
    dot: 'bg-amber-500',
    label: 'In Progress',
    subtitle: 'Still being worked at shift end',
  },
  'Watch-list': {
    icon: AlertTriangle,
    color: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    text: 'text-blue-700',
    dot: 'bg-blue-500',
    label: 'Watch Items',
    subtitle: 'Next Shift Attention',
  },
  Completed: {
    icon: CheckCircle2,
    color: 'text-emerald-600',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    text: 'text-emerald-700',
    dot: 'bg-emerald-500',
    label: 'Completed',
    subtitle: 'Resolved during this shift',
  },
};

const PROCESSING_STEPS = [
  'Filtering events...',
  'Collapsing updates...',
  'Detecting changes...',
  'Building handover...',
];

/* ── Small shared components ── */

function PriorityBadge({ priority }: { priority: string }) {
  const styles: Record<string, string> = {
    Critical: 'bg-red-100 text-red-700 border-red-200',
    High: 'bg-orange-100 text-orange-700 border-orange-200',
    Medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    Low: 'bg-gray-100 text-gray-600 border-gray-200',
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold border ${styles[priority] ?? styles.Low}`}
    >
      {priority}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    Open: 'bg-blue-100 text-blue-700 border-blue-200',
    Assigned: 'bg-indigo-100 text-indigo-700 border-indigo-200',
    Investigating: 'bg-amber-100 text-amber-700 border-amber-200',
    'In Progress': 'bg-amber-100 text-amber-700 border-amber-200',
    in_progress: 'bg-amber-100 text-amber-700 border-amber-200',
    Blocked: 'bg-red-100 text-red-700 border-red-200',
    Escalated: 'bg-red-100 text-red-700 border-red-200',
    Resolved: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    Closed: 'bg-gray-100 text-gray-600 border-gray-200',
    Completed: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold border ${styles[status] ?? 'bg-gray-100 text-gray-600 border-gray-200'}`}
    >
      {status}
    </span>
  );
}

function Tooltip({ text }: { text: string }) {
  return (
    <span className="group relative inline-flex items-center ml-1 cursor-help align-middle">
      <Info className="w-3 h-3 text-slate-300 hover:text-slate-500 transition-colors" />
      <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2.5 py-1.5 bg-slate-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-30 shadow-lg max-w-[220px] whitespace-normal text-center">
        {text}
      </span>
    </span>
  );
}

/* ── Shift Pulse metrics ── */

function PulseMetric({
  value,
  label,
  accent,
  tooltip,
}: {
  value: number | string;
  label: string;
  accent: string;
  tooltip: string;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm px-4 py-3">
      <div className={`text-2xl font-bold ${accent} leading-none`}>{value}</div>
      <div className="text-[11px] text-slate-500 mt-1 flex items-center">
        {label}
        <Tooltip text={tooltip} />
      </div>
    </div>
  );
}

function ShiftPulse({ result }: { result: HandoverResult }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
      <div className="flex items-center gap-2 mb-1">
        <div className="w-1.5 h-5 bg-blue-500 rounded-full" />
        <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wide">
          Shift Pulse
        </h2>
      </div>
      <p className="text-xs text-slate-400 mb-4 ml-3.5">What happened in this window</p>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <PulseMetric
          value={result.summary.included}
          label="Events Included"
          accent="text-emerald-600"
          tooltip="Events whose timestamp fell within the selected shift window."
        />
        <PulseMetric
          value={result.summary.uniqueRecords}
          label="Unique Records"
          accent="text-blue-600"
          tooltip="Distinct source + record ID combinations found in the included events."
        />
        <PulseMetric
          value={result.summary.rejected}
          label="Outside Window"
          accent="text-red-600"
          tooltip="Events rejected because their timestamp was outside the selected shift window."
        />
        <PulseMetric
          value={result.summary.meaningfulChanges}
          label="Meaningful Records"
          accent="text-amber-600"
          tooltip="Records where at least one field (status, priority, or owner) changed during the shift."
        />
        <PulseMetric
          value={result.summary.duplicatesCollapsed}
          label="Updates Collapsed"
          accent="text-purple-600"
          tooltip="Multiple updates belonging to the same source record were combined into one handover item."
        />
      </div>
    </div>
  );
}

/* ── Shift Story timeline ── */

function ShiftStory({
  items,
  shiftStart,
  shiftEnd,
  onJump,
}: {
  items: HandoverItem[];
  shiftStart: string;
  shiftEnd: string;
  onJump: (key: string) => void;
}) {
  const changed = items
    .filter((i) => i.changes.length > 0)
    .sort(
      (a, b) =>
        new Date(a.latestTimestamp).getTime() -
        new Date(b.latestTimestamp).getTime(),
    );

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
      <div className="flex items-center gap-2 mb-1">
        <GitCompare className="w-4 h-4 text-slate-600" />
        <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wide">
          Shift Story
        </h2>
      </div>
      <p className="text-xs text-slate-400 mb-4 ml-6">The key changes across this shift</p>

      {changed.length === 0 ? (
        <p className="text-sm text-slate-400 italic">
          No meaningful changes detected during this shift
        </p>
      ) : (
        <div className="relative pt-2 pb-1">
          <div className="absolute top-[20px] left-0 right-0 h-px bg-slate-200" />
          <div className="flex gap-2 overflow-x-auto pb-1">
            {/* Start marker */}
            <div className="flex flex-col items-center shrink-0" style={{ minWidth: 80 }}>
              <div className="text-[11px] font-mono text-slate-400 mb-1">
                {formatTime(shiftStart)}
              </div>
              <div className="w-3 h-3 rounded-full bg-slate-300 ring-4 ring-white shrink-0" />
              <div className="mt-1.5 text-[11px] text-slate-400 font-medium">
                Shift Start
              </div>
            </div>
            {/* Changed records */}
            {changed.map((item) => {
              const config = CATEGORY_CONFIG[item.category];
              const primaryChange = item.changes[0];
              return (
                <div
                  key={item.key}
                  className="flex flex-col items-center group cursor-pointer shrink-0"
                  style={{ minWidth: 120 }}
                  onClick={() => onJump(item.key)}
                >
                  <div className="text-[11px] font-mono text-slate-400 mb-1">
                    {formatTime(item.latestTimestamp)}
                  </div>
                  <div
                    className={`w-3 h-3 rounded-full ${config.dot} ring-4 ring-white shrink-0 transition-transform group-hover:scale-125`}
                  />
                  <div className="mt-1.5 text-center">
                    <div className="font-mono text-xs font-bold text-slate-800 group-hover:text-blue-600 transition-colors">
                      {item.record_id}
                    </div>
                    <div className="text-[11px] text-slate-500 leading-tight mt-0.5">
                      {primaryChange.field}: {primaryChange.from} → {primaryChange.to}
                    </div>
                  </div>
                </div>
              );
            })}
            {/* End marker */}
            <div className="flex flex-col items-center shrink-0" style={{ minWidth: 80 }}>
              <div className="text-[11px] font-mono text-slate-400 mb-1">
                {formatTime(shiftEnd)}
              </div>
              <div className="w-3 h-3 rounded-full bg-slate-300 ring-4 ring-white shrink-0" />
              <div className="mt-1.5 text-[11px] text-slate-400 font-medium">
                Shift End
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Next Shift at a Glance ── */

function NextShiftStrip({
  items,
  onJump,
}: {
  items: HandoverItem[];
  onJump: (key: string) => void;
}) {
  const counts = useMemo(() => {
    const map: Record<ChangeCategory, number> = {
      'Blockers / Escalations': 0,
      'In Progress': 0,
      'Watch-list': 0,
      Completed: 0,
    };
    for (const item of items) map[item.category]++;
    return map;
  }, [items]);

  const entries = CATEGORY_ORDER.map((cat) => ({ cat, count: counts[cat] }));

  const handleClick = (cat: ChangeCategory) => {
    const first = items.find((i) => i.category === cat);
    if (first) onJump(first.key);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
      <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wide mb-1">
        Next Shift at a Glance
      </h2>
      <p className="text-xs text-slate-400 mb-3">What needs attention first</p>
      <div className="flex flex-wrap gap-3">
        {entries.map(({ cat, count }) => {
          const config = CATEGORY_CONFIG[cat];
          return (
            <button
              key={cat}
              onClick={() => handleClick(cat)}
              className={`flex items-center gap-2 ${config.bg} border ${config.border} rounded-lg px-3 py-2 hover:shadow-sm transition-shadow cursor-pointer text-left`}
            >
              <div className={`w-2 h-2 rounded-full ${config.dot}`} />
              <span className={`text-lg font-bold ${config.text}`}>{count}</span>
              <span className="text-xs text-slate-600">{config.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ── Handover Card ── */

function HandoverCard({
  item,
  onEvidence,
  highlighted,
  cardRef,
}: {
  item: HandoverItem;
  onEvidence: (item: HandoverItem) => void;
  highlighted: boolean;
  cardRef: (el: HTMLDivElement | null) => void;
}) {
  const config = CATEGORY_CONFIG[item.category];
  const Icon = config.icon;
  return (
    <div
      ref={cardRef}
      className={`bg-white rounded-xl border shadow-sm overflow-hidden transition-all duration-300 ${
        highlighted
          ? 'border-blue-400 ring-2 ring-blue-200'
          : config.border
      }`}
    >
      <div
        className={`${config.bg} px-4 py-2.5 flex items-center justify-between border-b ${config.border}`}
      >
        <div className="flex items-center gap-2">
          <Icon className={`w-4 h-4 ${config.color}`} />
          <span className={`text-sm font-semibold ${config.text}`}>
            {item.category}
          </span>
        </div>
        <span className="text-xs text-slate-500 font-mono">{item.source}</span>
      </div>

      <div className="p-4">
        {/* ROW 1: record ID + badges */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <span className="font-mono text-sm font-bold text-slate-800">
            {item.record_id}
          </span>
          <div className="flex items-center gap-1.5 shrink-0">
            <PriorityBadge priority={item.finalPriority} />
            <StatusBadge status={item.finalStatus} />
          </div>
        </div>

        {/* ROW 2: summary */}
        <p className="text-sm text-slate-600 mb-3">{item.summary}</p>

        {/* ROW 3: WHAT CHANGED or CURRENT STATE */}
        {item.changes.length > 0 ? (
          <div className="mb-3">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-1.5">
              What Changed
            </div>
            <div className="space-y-1.5">
              {item.changes.map((c, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-slate-400 font-medium w-16 shrink-0 text-xs">
                    {c.field}
                  </span>
                  <span className="text-slate-600 text-xs whitespace-nowrap">
                    {c.from}
                  </span>
                  <span className="flex-1 border-t border-dashed border-slate-300 mx-1" />
                  <ArrowRight className="w-3 h-3 text-slate-400 shrink-0" />
                  <span className="text-slate-900 font-semibold text-xs whitespace-nowrap">
                    {c.to}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="mb-3">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-1">
              Current State
            </div>
            <div className="text-xs text-slate-600">
              {item.finalStatus} • {item.finalPriority} • {item.finalOwner}
            </div>
            <div className="text-[11px] text-slate-400 italic mt-1">
              No status, priority, or ownership transition occurred during this shift.
            </div>
          </div>
        )}

        {/* WHY IT'S HERE */}
        <div className="pt-2.5 border-t border-slate-100">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-0.5">
            Why It's Here
          </div>
          <div className="text-xs text-slate-600 mb-2">{item.humanReason}</div>

          {/* SOURCE PROOF ROW */}
          <div className="flex items-center justify-between gap-2">
            <div className="text-[11px] text-slate-400 font-mono truncate">
              {item.source} • {item.record_id} • Last update{' '}
              {formatTime(item.latestTimestamp)} • {item.events.length} source events
            </div>
            <button
              onClick={() => onEvidence(item)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg px-3 py-1.5 transition-colors shrink-0 focus:outline-none focus:ring-2 focus:ring-blue-400"
            >
              <Eye className="w-3.5 h-3.5" />
              View Evidence
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Category Section ── */

function CategorySection({
  title,
  subtitle,
  items,
  onEvidence,
  highlightedKey,
  registerRef,
  sectionRef,
}: {
  title: ChangeCategory;
  subtitle?: string;
  items: HandoverItem[];
  onEvidence: (item: HandoverItem) => void;
  highlightedKey: string | null;
  registerRef: (key: string, el: HTMLDivElement | null) => void;
  sectionRef: (el: HTMLDivElement | null) => void;
}) {
  const [open, setOpen] = useState(true);
  const config = CATEGORY_CONFIG[title];
  const Icon = config.icon;
  return (
    <div ref={sectionRef}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between mb-3 group"
      >
        <div className="flex items-center gap-2">
          <div className={`${config.bg} ${config.color} rounded-lg p-1.5`}>
            <Icon className="w-4 h-4" />
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className={`text-lg font-bold ${config.text}`}>{title}</h3>
            {subtitle && (
              <span className="text-xs text-slate-400 hidden sm:inline">
                {subtitle}
              </span>
            )}
          </div>
          <span className="text-sm text-slate-400 font-normal">
            {items.length}
          </span>
        </div>
        {open ? (
          <ChevronUp className="w-5 h-5 text-slate-400 group-hover:text-slate-600" />
        ) : (
          <ChevronDown className="w-5 h-5 text-slate-400 group-hover:text-slate-600" />
        )}
      </button>
      {open && items.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {items.map((item) => (
            <HandoverCard
              key={item.key}
              item={item}
              onEvidence={onEvidence}
              highlighted={highlightedKey === item.key}
              cardRef={(el) => registerRef(item.key, el)}
            />
          ))}
        </div>
      )}
      {open && items.length === 0 && (
        <div className="bg-white rounded-xl border border-dashed border-slate-200 p-6 text-center">
          <p className="text-sm text-slate-400">Nothing to report</p>
          <p className="text-xs text-slate-300 mt-1">
            No matching source events were found for this category during the
            selected shift.
          </p>
        </div>
      )}
    </div>
  );
}

/* ── Evidence Drawer ── */

function EvidenceDrawer({
  item,
  onClose,
}: {
  item: HandoverItem | null;
  onClose: () => void;
}) {
  if (!item) return null;
  const config = CATEGORY_CONFIG[item.category];
  const allTraceable = !!(item.source && item.record_id && item.latestTimestamp);

  return (
    <>
      <div
        className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-sm print:hidden animate-fadeIn"
        onClick={onClose}
      />
      <aside className="fixed right-0 top-0 bottom-0 z-50 w-full max-w-md bg-white shadow-2xl flex flex-col print:hidden animate-[slideIn_0.2s_ease-out]">
        <div className="bg-slate-800 px-5 py-4 flex items-center justify-between shrink-0">
          <div>
            <h3 className="text-white font-semibold text-base uppercase tracking-wide">
              Evidence Trail
            </h3>
            <p className="text-slate-400 text-sm font-mono">{item.record_id}</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors p-1 focus:outline-none focus:ring-2 focus:ring-white/30 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 p-5">
          <p className="text-sm text-slate-600 mb-5">
            Every statement in this handover item comes from these source events.
          </p>

          {/* Chronological Events */}
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-3">
            Chronological Source Events
          </div>
          <div className="relative mb-6">
            <div className="absolute left-3 top-2 bottom-2 w-px bg-slate-200" />
            <div className="space-y-4">
              {item.events.map((ev, i) => (
                <div key={ev.id} className="relative pl-8">
                  <div
                    className={`absolute left-2 top-1 w-2.5 h-2.5 rounded-full ${config.dot} ring-4 ring-white`}
                  />
                  <div className="text-sm font-mono text-slate-500">
                    {formatTime(ev.timestamp)}
                  </div>
                  <div className="text-sm text-slate-800 font-medium mt-0.5">
                    {ev.status}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {ev.priority} • {ev.owner}
                  </div>
                  {i < item.events.length - 1 && (
                    <div className="text-[11px] text-slate-300 mt-1">↓</div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Classification Proof */}
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-2">
            Classification Proof
          </div>
          <div className="bg-slate-50 rounded-lg px-3 py-2.5 mb-5 text-sm">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-slate-600">{item.finalStatus}</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              <span className={`font-semibold ${config.text}`}>
                {item.category}
              </span>
            </div>
            <div className="text-xs text-slate-500">
              Because: {item.classificationReason}
            </div>
          </div>

          {/* Source Proof */}
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-2">
            Source Proof
          </div>
          <div className="bg-slate-50 rounded-lg px-3 py-2.5 mb-3 text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-500">System</span>
              <span className="text-slate-800 font-medium">{item.source}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Record ID</span>
              <span className="text-slate-800 font-mono font-medium">
                {item.record_id}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Latest event</span>
              <span className="text-slate-800 font-mono">
                {formatDate(item.latestTimestamp)} • {formatTime(item.latestTimestamp)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Events used</span>
              <span className="text-slate-800 font-medium">
                {item.events.length}
              </span>
            </div>
          </div>

          {allTraceable && (
            <div className="flex items-center gap-1.5 text-sm text-emerald-600 font-medium">
              <BadgeCheck className="w-4 h-4" />
              Grounded in source data
            </div>
          )}
        </div>
      </aside>
    </>
  );
}

/* ── Rejected Events Modal ── */

function RejectedModal({
  events,
  onClose,
}: {
  events: RejectedEvent[];
  onClose: () => void;
}) {
  if (events.length === 0) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm print:hidden animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-slate-800 px-5 py-4 flex items-center justify-between">
          <h3 className="text-white font-semibold text-lg">Excluded Events</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors p-1 focus:outline-none focus:ring-2 focus:ring-white/30 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 overflow-y-auto">
          <p className="text-sm text-slate-500 mb-4">
            These events fell outside the selected shift window and were excluded
            from the handover.
          </p>
          <div className="space-y-2">
            {events.map(({ event: ev, reason }) => (
              <div
                key={ev.id}
                className="grid grid-cols-4 gap-2 items-center bg-slate-50 rounded-lg px-3 py-2 text-sm"
              >
                <span className="font-mono font-semibold text-slate-700">
                  {ev.record_id}
                </span>
                <span className="text-xs text-slate-400">{ev.source}</span>
                <span className="text-xs text-slate-500 font-mono">
                  {formatTimestamp(ev.timestamp)}
                </span>
                <span className="text-xs text-red-500 font-medium text-right">
                  {reason}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Shift Window Audit ── */

function ShiftWindowAudit({
  shiftStart,
  shiftEnd,
  result,
  onInspect,
}: {
  shiftStart: string;
  shiftEnd: string;
  result: HandoverResult;
  onInspect: () => void;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 print:hidden">
      <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wide mb-1">
        Shift Window Audit
      </h2>
      <p className="text-xs text-slate-400 mb-3">
        Proof that only this shift was analysed
      </p>
      <div className="flex items-center gap-3 text-sm mb-3">
        <span className="font-mono font-semibold text-slate-700">
          {formatTime(shiftStart)}
        </span>
        <div className="flex-1 h-2 bg-slate-200 rounded-full relative">
          <div className="absolute inset-0 bg-blue-200 rounded-full" />
        </div>
        <span className="font-mono font-semibold text-slate-700">
          {formatTime(shiftEnd)}
        </span>
      </div>
      <div className="text-center text-[11px] text-slate-400 mb-3">Selected window</div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-emerald-600">
          <CheckCircle2 className="w-4 h-4" />
          <span className="text-sm font-semibold">
            {result.summary.included} events included
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-slate-400">
          <XCircle className="w-4 h-4" />
          <span className="text-sm font-semibold">
            {result.summary.rejected} events excluded
          </span>
        </div>
        {result.rejectedEvents.length > 0 && (
          <button
            onClick={onInspect}
            className="ml-auto text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg px-3 py-1.5 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            Inspect Excluded Events
          </button>
        )}
      </div>
    </div>
  );
}

/* ── Handover Integrity ── */

function HandoverIntegrity({ result }: { result: HandoverResult }) {
  const allTraceable = result.items.every(
    (i) => i.source && i.record_id && i.latestTimestamp,
  );
  const duplicateRecords = result.items.filter((i) => i.events.length > 1).length;
  const boundaryEnforced = result.rejectedEvents.length === result.summary.rejected;

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
      <div className="flex items-center gap-2 mb-1">
        <ShieldCheck className="w-4 h-4 text-slate-600" />
        <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wide">
          Handover Integrity
        </h2>
      </div>
      <p className="text-xs text-slate-400 mb-4 ml-6">
        Automatically verified before export
      </p>
      <div className="space-y-2.5">
        <div className="flex items-start gap-2">
          <BadgeCheck
            className={`w-4 h-4 shrink-0 mt-0.5 ${allTraceable ? 'text-emerald-500' : 'text-red-500'}`}
          />
          <div>
            <div className="text-sm text-slate-700">
              {allTraceable ? '100% Source Traceable' : 'Traceability incomplete'}
            </div>
            <div className="text-[11px] text-slate-400">
              Every handover item has source + record ID + timestamp
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <BadgeCheck
            className={`w-4 h-4 shrink-0 mt-0.5 ${duplicateRecords === 0 ? 'text-emerald-500' : 'text-amber-500'}`}
          />
          <div>
            <div className="text-sm text-slate-700">
              {duplicateRecords} Duplicate Records
            </div>
            <div className="text-[11px] text-slate-400">
              Grouped by source + record ID
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <BadgeCheck
            className={`w-4 h-4 shrink-0 mt-0.5 ${boundaryEnforced ? 'text-emerald-500' : 'text-red-500'}`}
          />
          <div>
            <div className="text-sm text-slate-700">Shift Boundary Enforced</div>
            <div className="text-[11px] text-slate-400">
              Outside-window events excluded
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <BadgeCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-500" />
          <div>
            <div className="text-sm text-slate-700">Deterministic Output</div>
            <div className="text-[11px] text-slate-400">
              Same input produces the same handover records
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Print Report ── */

function PrintReport({
  result,
  shiftStart,
  shiftEnd,
  sources,
}: {
  result: HandoverResult;
  shiftStart: string;
  shiftEnd: string;
  sources: Source[];
}) {
  const grouped = useMemo(() => {
    const cats: ChangeCategory[] = [
      'Blockers / Escalations',
      'In Progress',
      'Watch-list',
      'Completed',
    ];
    const map: Record<ChangeCategory, HandoverItem[]> = {
      'Blockers / Escalations': [],
      'In Progress': [],
      'Watch-list': [],
      Completed: [],
    };
    for (const item of result.items) map[item.category].push(item);
    return cats.map((c) => ({ category: c, items: map[c] }));
  }, [result]);

  return (
    <div className="hidden print:block">
      <h1 className="text-xl font-bold">ShiftDiff — Shift Handover Report</h1>
      <p className="text-sm mt-1">
        Shift: {formatDate(shiftStart)} {formatTime(shiftStart)} →{' '}
        {formatDate(shiftEnd)} {formatTime(shiftEnd)}
      </p>
      <p className="text-sm">Sources: {sources.join(' • ')}</p>
      <p className="text-sm mb-4">
        Generated: {formatTimestamp(new Date().toISOString())}
      </p>

      <div className="border-y border-slate-300 py-2 mb-4">
        <div className="text-xs font-bold uppercase mb-1">Shift Summary</div>
        <div className="text-sm">
          Events analysed: {result.summary.total} • Events included:{' '}
          {result.summary.included} • Unique records: {result.summary.uniqueRecords} •
          Outside-window excluded: {result.summary.rejected} • Updates collapsed:{' '}
          {result.summary.duplicatesCollapsed}
        </div>
      </div>

      {grouped.map(({ category, items }) => (
        <div key={category} className="mb-4 break-inside-avoid">
          <h2 className="text-base font-bold uppercase mb-2">{category}</h2>
          {items.length === 0 ? (
            <p className="text-sm italic mb-2">Nothing to report</p>
          ) : (
            items.map((item) => (
              <div
                key={item.key}
                className="mb-3 border-b border-slate-200 pb-2 break-inside-avoid"
              >
                <div className="font-mono font-bold text-sm">{item.record_id}</div>
                <div className="text-sm">{item.summary}</div>
                <div className="text-xs mt-0.5">
                  Final status: {item.finalStatus} • Priority: {item.finalPriority} •
                  Owner: {item.finalOwner}
                </div>
                {item.changes.length > 0 ? (
                  <div className="text-xs mt-1">
                    Changes:{' '}
                    {item.changes
                      .map((c) => `${c.field}: ${c.from} → ${c.to}`)
                      .join('; ')}
                  </div>
                ) : (
                  <div className="text-xs mt-1 italic">
                    No status, priority, or ownership transition occurred during this
                    shift.
                  </div>
                )}
                <div className="text-xs mt-0.5 text-slate-500">
                  Source: {item.source} • Timestamp:{' '}
                  {formatTimestamp(item.latestTimestamp)}
                </div>
              </div>
            ))
          )}
        </div>
      ))}

      <div className="border-t border-slate-300 pt-2 mt-4 break-inside-avoid">
        <div className="text-xs font-bold uppercase mb-1">Handover Integrity</div>
        <div className="text-xs">
          Source traceability:{' '}
          {result.items.every((i) => i.source && i.record_id && i.latestTimestamp)
            ? '100%'
            : 'Incomplete'}{' '}
          • Duplicate records:{' '}
          {result.items.filter((i) => i.events.length > 1).length} • Shift-window
          check: Enforced • Deterministic output: Verified
        </div>
      </div>
    </div>
  );
}

/* ── Main App ── */

export default function App() {
  const [shiftStart, setShiftStart] = useState(DEFAULT_SHIFT_START);
  const [shiftEnd, setShiftEnd] = useState(DEFAULT_SHIFT_END);
  const [sources, setSources] = useState<Source[]>([...ALL_SOURCES]);
  const [result, setResult] = useState<HandoverResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [evidenceItem, setEvidenceItem] = useState<HandoverItem | null>(null);
  const [showRejected, setShowRejected] = useState(false);
  const [highlightedKey, setHighlightedKey] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [processStep, setProcessStep] = useState(0);
  const cardRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const sectionRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  const handleGenerate = () => {
    setError(null);
    const startMs = new Date(shiftStart).getTime();
    const endMs = new Date(shiftEnd).getTime();
    if (isNaN(startMs) || isNaN(endMs)) {
      setError('Please enter valid shift start and end times.');
      return;
    }
    if (endMs <= startMs) {
      setError('Shift end must be later than shift start.');
      return;
    }
    if (sources.length === 0) {
      setError('Select at least one data source.');
      return;
    }

    setProcessing(true);
    setProcessStep(0);
    let step = 0;
    const interval = setInterval(() => {
      step++;
      if (step < PROCESSING_STEPS.length) {
        setProcessStep(step);
      } else {
        clearInterval(interval);
        setResult(generateHandover(MOCK_EVENTS, shiftStart, shiftEnd, sources));
        setProcessing(false);
      }
    }, 200);
  };

  const handlePrint = () => window.print();

  const grouped = useMemo(() => {
    if (!result) return null;
    const map: Record<ChangeCategory, HandoverItem[]> = {
      'Blockers / Escalations': [],
      'In Progress': [],
      'Watch-list': [],
      Completed: [],
    };
    for (const item of result.items) map[item.category].push(item);
    return CATEGORY_ORDER.map((c) => ({ category: c, items: map[c] }));
  }, [result]);

  const isVerified = useMemo(() => {
    if (!result || result.items.length === 0) return false;
    return result.items.every((i) => i.source && i.record_id && i.latestTimestamp);
  }, [result]);

  const jumpToCard = (key: string) => {
    setHighlightedKey(key);
    const el = cardRefs.current.get(key);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(() => setHighlightedKey(null), 2500);
  };

  const registerRef = (key: string, el: HTMLDivElement | null) => {
    if (el) cardRefs.current.set(key, el);
    else cardRefs.current.delete(key);
  };

  const registerSectionRef = (cat: string, el: HTMLDivElement | null) => {
    if (el) sectionRefs.current.set(cat, el);
    else sectionRefs.current.delete(cat);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* ── HEADER ── */}
      <header className="bg-slate-900 text-white print:hidden">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between py-3">
            <div className="flex items-center gap-2.5">
              <div className="bg-blue-500/20 rounded-lg p-1.5">
                <Layers className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight leading-none">
                  ShiftDiff
                </h1>
                <p className="text-slate-400 text-xs mt-0.5">
                  Know what changed before you take over.
                </p>
                <p className="text-slate-500 text-[10px] mt-0.5">
                  Evidence-Driven Shift Handover
                </p>
              </div>
            </div>
            {isVerified ? (
              <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-2.5 py-1.5">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs font-semibold text-emerald-400">
                  SHIFT VERIFIED
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 bg-slate-700/50 border border-slate-600 rounded-lg px-2.5 py-1.5">
                <div className="w-2 h-2 rounded-full border border-slate-400" />
                <span className="text-xs font-semibold text-slate-400">
                  READY TO GENERATE
                </span>
              </div>
            )}
          </div>

          {/* Compact shift control bar */}
          <div className="flex flex-wrap items-end gap-3 pb-3 border-t border-slate-700/50 pt-3">
            <div className="flex items-end gap-2">
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5 uppercase tracking-wide">
                  From
                </label>
                <input
                  type="datetime-local"
                  value={shiftStart}
                  onChange={(e) => setShiftStart(e.target.value)}
                  className="rounded-lg bg-slate-800 border border-slate-700 text-white text-sm px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500 [color-scheme:dark]"
                />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 mb-1.5" />
              <div>
                <label className="block text-[10px] text-slate-400 mb-0.5 uppercase tracking-wide">
                  To
                </label>
                <input
                  type="datetime-local"
                  value={shiftEnd}
                  onChange={(e) => setShiftEnd(e.target.value)}
                  className="rounded-lg bg-slate-800 border border-slate-700 text-white text-sm px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500 [color-scheme:dark]"
                />
              </div>
            </div>
            <div className="flex items-center gap-3">
              {ALL_SOURCES.map((s) => (
                <label
                  key={s}
                  className="flex items-center gap-1.5 text-sm text-slate-300 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={sources.includes(s)}
                    onChange={(e) => {
                      if (e.target.checked) setSources([...sources, s]);
                      else setSources(sources.filter((x) => x !== s));
                    }}
                    className="rounded border-slate-600 text-blue-600 focus:ring-blue-500 bg-slate-800"
                  />
                  {s.replace(' System', '').replace(' Logs', '')}
                </label>
              ))}
            </div>
            <button
              onClick={handleGenerate}
              disabled={processing}
              className="bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 disabled:cursor-not-allowed text-white font-semibold rounded-lg px-4 py-2 text-sm transition-colors flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
            >
              {processing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  {PROCESSING_STEPS[processStep]}
                </>
              ) : (
                <>
                  <Filter className="w-3.5 h-3.5" />
                  Generate Handover
                </>
              )}
            </button>
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2 mb-3">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-5 print:py-2 print:max-w-none">
        {result && grouped ? (
          <div className="space-y-5">
            {/* SHIFT PULSE */}
            <ShiftPulse result={result} />

            {/* SHIFT STORY */}
            <ShiftStory
              items={result.items}
              shiftStart={shiftStart}
              shiftEnd={shiftEnd}
              onJump={jumpToCard}
            />

            {/* NEXT SHIFT AT A GLANCE */}
            <NextShiftStrip items={result.items} onJump={jumpToCard} />

            {/* HANDOVER SECTIONS */}
            <div className="space-y-5">
              {grouped.map(({ category, items }) => (
                <CategorySection
                  key={category}
                  title={category}
                  subtitle={
                    category === 'Watch-list'
                      ? 'Next Shift Attention'
                      : CATEGORY_CONFIG[category].subtitle
                  }
                  items={items}
                  onEvidence={setEvidenceItem}
                  highlightedKey={highlightedKey}
                  registerRef={registerRef}
                  sectionRef={(el) => registerSectionRef(category, el)}
                />
              ))}
            </div>

            {/* SHIFT WINDOW AUDIT */}
            <ShiftWindowAudit
              shiftStart={shiftStart}
              shiftEnd={shiftEnd}
              result={result}
              onInspect={() => setShowRejected(true)}
            />

            {/* HANDOVER INTEGRITY */}
            <HandoverIntegrity result={result} />

            {/* EXPORT */}
            <div className="print:hidden">
              <button
                onClick={handlePrint}
                className="w-full bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-xl px-4 py-3 text-sm transition-colors flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
              >
                <Download className="w-4 h-4" />
                Download Handover PDF
              </button>
            </div>

            {/* Print report */}
            <PrintReport
              result={result}
              shiftStart={shiftStart}
              shiftEnd={shiftEnd}
              sources={sources}
            />
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-dashed border-slate-300 p-12 text-center">
            <Layers className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 text-sm">
              Configure your shift window and click{' '}
              <strong>Generate Handover</strong> to see the report.
            </p>
          </div>
        )}
      </main>

      <EvidenceDrawer item={evidenceItem} onClose={() => setEvidenceItem(null)} />
      {showRejected && (
        <RejectedModal
          events={result?.rejectedEvents ?? []}
          onClose={() => setShowRejected(false)}
        />
      )}
    </div>
  );
}
